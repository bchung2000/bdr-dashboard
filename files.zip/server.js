/**
 * BDR Command Center — backend
 * Deploy target: Render.com (free web service + free Postgres)
 *
 * Endpoints:
 *   POST /api/signup            { email, password }           -> { token }
 *   POST /api/login             { email, password }           -> { token }
 *   GET  /api/me                (Bearer token)                -> { email, subscription }
 *   POST /api/create-checkout-session (Bearer token)          -> { url }  (Stripe Checkout)
 *   POST /api/create-portal-session   (Bearer token)          -> { url }  (manage/cancel billing)
 *   POST /api/claude            (Bearer token, active sub)    -> proxied Anthropic API response
 *   POST /api/stripe-webhook    (Stripe only)                 -> keeps subscription status in sync
 *
 * Required environment variables (set in Render dashboard):
 *   DATABASE_URL           — from Render Postgres
 *   JWT_SECRET             — any long random string
 *   STRIPE_SECRET_KEY      — sk_live_... (or sk_test_... while testing)
 *   STRIPE_WEBHOOK_SECRET  — whsec_... from the Stripe webhook you create
 *   STRIPE_PRICE_ID        — price_... of your subscription price
 *   ANTHROPIC_API_KEY      — your Anthropic key (server-side only, never sent to browsers)
 *   FRONTEND_URL           — https://bchung2000.github.io/bdr-dashboard
 */

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Stripe = require("stripe");
const { Pool } = require("pg");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: false }));

// Stripe webhook needs the RAW body — register it before express.json()
app.post("/api/stripe-webhook", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature failed:", err.message);
    return res.status(400).send("Bad signature");
  }

  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      await pool.query(
        "UPDATE users SET stripe_customer_id=$1, subscription_status='active' WHERE id=$2",
        [session.customer, Number(session.client_reference_id)]
      );
    }
    if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
      const sub = event.data.object;
      const status = (sub.status === "active" || sub.status === "trialing") ? "active" : "inactive";
      await pool.query(
        "UPDATE users SET subscription_status=$1 WHERE stripe_customer_id=$2",
        [status, sub.customer]
      );
    }
  } catch (err) {
    console.error("Webhook handler error:", err);
    return res.status(500).send("Handler error");
  }
  res.json({ received: true });
});

app.use(express.json({ limit: "2mb" }));

// ---------- DB bootstrap ----------
async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      stripe_customer_id TEXT,
      subscription_status TEXT DEFAULT 'none',
      created_at TIMESTAMPTZ DEFAULT now()
    );
  `);
  console.log("DB ready");
}

// ---------- helpers ----------
function sign(user) {
  return jwt.sign({ uid: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "30d" });
}

async function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Not signed in" });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const { rows } = await pool.query("SELECT * FROM users WHERE id=$1", [payload.uid]);
    if (!rows[0]) return res.status(401).json({ error: "Account not found" });
    req.user = rows[0];
    next();
  } catch {
    return res.status(401).json({ error: "Session expired — sign in again" });
  }
}

function requireActiveSub(req, res, next) {
  if (req.user.subscription_status !== "active") {
    return res.status(402).json({ error: "Subscription required" });
  }
  next();
}

// ---------- auth routes ----------
app.post("/api/signup", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password || password.length < 8) {
    return res.status(400).json({ error: "Valid email and a password of 8+ characters required" });
  }
  const hash = await bcrypt.hash(password, 10);
  try {
    const { rows } = await pool.query(
      "INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING *",
      [email.toLowerCase().trim(), hash]
    );
    res.json({ token: sign(rows[0]) });
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "An account with that email already exists" });
    console.error(err);
    res.status(500).json({ error: "Could not create account" });
  }
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body || {};
  const { rows } = await pool.query("SELECT * FROM users WHERE email=$1", [(email || "").toLowerCase().trim()]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(password || "", user.password_hash))) {
    return res.status(401).json({ error: "Email or password is incorrect" });
  }
  res.json({ token: sign(user) });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ email: req.user.email, subscription: req.user.subscription_status });
});

// ---------- billing ----------
app.post("/api/create-checkout-session", auth, async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      client_reference_id: String(req.user.id),
      customer: req.user.stripe_customer_id || undefined,
      customer_email: req.user.stripe_customer_id ? undefined : req.user.email,
      success_url: `${process.env.FRONTEND_URL}/app.html?welcome=1`,
      cancel_url: `${process.env.FRONTEND_URL}/index.html#pricing`,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not start checkout" });
  }
});

app.post("/api/create-portal-session", auth, async (req, res) => {
  if (!req.user.stripe_customer_id) return res.status(400).json({ error: "No billing account yet" });
  const session = await stripe.billingPortal.sessions.create({
    customer: req.user.stripe_customer_id,
    return_url: `${process.env.FRONTEND_URL}/app.html`,
  });
  res.json({ url: session.url });
});

// ---------- gated Anthropic proxy (also fixes CORS) ----------
app.post("/api/claude", auth, requireActiveSub, async (req, res) => {
  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(req.body),
    });
    const data = await upstream.json();
    res.status(upstream.status).json(data);
  } catch (err) {
    console.error("Claude proxy error:", err);
    res.status(502).json({ error: "AI service unavailable — try again" });
  }
});

app.get("/", (_req, res) => res.send("BDR Command Center API is running"));

const PORT = process.env.PORT || 3000;
init().then(() => {
  app.listen(PORT, () => console.log("API listening on", PORT));
});
