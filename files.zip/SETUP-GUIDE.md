# BDR Command Center — Site Setup Guide

## Part 0 — Get the site live TODAY (demo mode, 10 min, no backend)

The site ships in **demo mode**: accounts and sign-in work entirely in the visitor's
browser, checkout is simulated, and the full flow works — landing → login → dashboard.

1. In your `bdr-dashboard` GitHub repo, delete the old `index.html` (or rename it
   `old-dashboard.html` to keep a copy).
2. Upload these 5 files: `index.html`, `auth.html`, `app.html`, `gate.js`, `config.js`.
3. Wait ~1 minute for GitHub Pages to rebuild. Done — test the flow:
   Launch dashboard → create an account → you're in the app.

Demo mode honesty: accounts exist only in each visitor's own browser, nobody is charged,
and the paywall is cosmetic (a technical person could bypass it). It's perfect for
showing the product and testing UX — Parts 1–5 below make it real.

When you're ready for real subscriptions, everything below stays the same, and the
**only frontend change is one line in `config.js`** (paste your Render URL).

---

You're shipping two things: a **static frontend** (GitHub Pages, free) and a **backend API**
(Render, free tier). Stripe handles payments. Total monthly cost to run: $0 until you have
real traffic, plus Anthropic API usage (covered by subscriptions).

## How the pieces fit

```
GitHub Pages (free)                    Render (free)              Stripe
┌─────────────────────┐            ┌──────────────────┐      ┌──────────────┐
│ index.html  landing │            │ server.js        │      │ Checkout     │
│ auth.html   sign-in ├── fetch ──▶│ · accounts (JWT) │◀────▶│ Subscriptions│
│ app.html    THE APP │            │ · sub gating     │      │ Webhooks     │
│ gate.js     paywall │            │ · Claude proxy ──┼──▶ api.anthropic.com
└─────────────────────┘            │ Postgres (free)  │
                                   └──────────────────┘
```

The backend proxy also **fixes your CORS problem** — the dashboard's AI features will
finally work on the hosted version, and subscribers never need their own API key.

---

## Part 1 — Stripe (15 min)

1. Create an account at stripe.com (use **Test mode** until everything works).
2. **Products → Add product** → name "BDR Command Center Pro" → Recurring, $19/month →
   Save. Copy the **Price ID** (`price_...`).
3. **Developers → API keys** → copy the **Secret key** (`sk_test_...`).
4. Webhook comes later (needs your Render URL first).

## Part 2 — Render backend (20 min, from your personal computer)

1. Create a new GitHub repo `bdr-api` and upload `server.js` + `package.json`.
2. On render.com: **New → PostgreSQL** (free plan) → after it creates, copy the
   **Internal Database URL**.
3. **New → Web Service** → connect the `bdr-api` repo → runtime Node →
   build command `npm install` → start command `npm start` → free plan.
4. In the service's **Environment** tab add:
   | Key | Value |
   |---|---|
   | DATABASE_URL | (internal DB URL from step 2) |
   | JWT_SECRET | any long random string — mash the keyboard for 40+ chars |
   | STRIPE_SECRET_KEY | sk_test_... |
   | STRIPE_PRICE_ID | price_... |
   | ANTHROPIC_API_KEY | your key from console.anthropic.com |
   | FRONTEND_URL | https://bchung2000.github.io/bdr-dashboard |
   | STRIPE_WEBHOOK_SECRET | (placeholder for now — fill in Part 3) |
5. Deploy. Your API URL will look like `https://bdr-api-xxxx.onrender.com`.
   Opening it should show "BDR Command Center API is running".

## Part 3 — Stripe webhook (5 min)

1. Stripe → **Developers → Webhooks → Add endpoint**.
2. URL: `https://YOUR-SERVICE.onrender.com/api/stripe-webhook`
3. Events: `checkout.session.completed`, `customer.subscription.updated`,
   `customer.subscription.deleted`.
4. Copy the **Signing secret** (`whsec_...`) → paste into STRIPE_WEBHOOK_SECRET on
   Render → service redeploys automatically.

## Part 4 — Flip the frontend to live mode (1 min)

1. In your `bdr-dashboard` repo, edit **`config.js`**:
   change `API: ""` to `API: "https://YOUR-SERVICE.onrender.com"` (your real Render URL,
   no trailing slash). Commit.
2. That's it — auth.html and gate.js read the same config and switch to real accounts,
   Stripe Checkout, and server-verified access automatically.

## Part 5 — Test the whole flow (10 min)

Stripe Test mode card: **4242 4242 4242 4242**, any future date, any CVC.

1. Visit your landing page → Launch → should land on auth.html.
2. Create an account → should bounce to Stripe Checkout → pay with the test card →
   should land on app.html with everything unlocked.
3. Open app.html in an incognito window → should bounce to auth.html. ✅ Paywall works.
4. Run an AI feature (Account Intelligence) → should work with no API key prompt. ✅ CORS fixed.
5. In Stripe → cancel the test subscription → refresh app.html → should bounce to
   pricing. ✅ Webhook works.

When all five pass, flip Stripe to **Live mode**, swap in the live `sk_live_` key and a
live webhook secret, and you're in business.

---

## Honest fine print

- **Render free tier sleeps** after 15 min idle — first request takes ~30s to wake. Fine
  for launch; the $7/mo tier removes it when you have paying users.
- **Watch your Anthropic usage** vs. revenue in console.anthropic.com. At ~$0.003/request
  a heavy user costs you maybe $2–3/mo against $19 — healthy, but set a monthly spend
  limit in the console as a circuit breaker.
- **Taxes/business**: Stripe will ask for your details; revenue is self-employment income.
  Worth a conversation with a tax person once money is real.
- **Day-job check**: this started as an Infor-workflow tool. Before charging the public,
  genericize the content (no Infor-confidential messaging, references, or customer data)
  and check your employment agreement's moonlighting/IP clauses. The version you sell
  should be a generic BDR tool, not Infor's playbook.
- **Password resets** aren't built yet (kept v1 simple). When you get real users, the next
  build is a "forgot password" email flow — I can add it with Resend or Postmark.
